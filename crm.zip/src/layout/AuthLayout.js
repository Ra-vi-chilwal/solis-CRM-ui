import React from 'react'
import Login from '../views/pages/login/Login'

function AuthLayout() {
  return (
    <div>
        <Login/>
    </div>
  )
}

export default AuthLayout