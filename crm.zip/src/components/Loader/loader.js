import React from 'react';
import GIF from "./loader.gif";
function loader() {
  return (
    <div><img src={GIF}/></div>
  )
}

export default loader