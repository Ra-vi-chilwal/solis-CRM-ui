export const  setSidebar =(sidebar)=>({
type:"SET_SIDEBAR",
payload:sidebar
})  