export const GetAllLead_SUCCESS = "GetAllLead_SUCCESS";
export const GetAllLead_REQUEST = "GetAllLead_REQUEST";
export const GetAllLead_FAIL = "GetAllLead_FAIL";