export const CARD_REQUEST = "CARD_REQUEST";
export const CARD_SUCCESS = "CARD_SUCCESS";
export const CARD_FAIL = "CARD_FAIL";