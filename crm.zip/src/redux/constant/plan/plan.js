export const PLAN_REQUEST = "PLAN_REQUEST";
export const PLAN_SUCCESS = "PLAN_SUCCESS";
export const PLAN_FAIL = "PLAN_FAIL";