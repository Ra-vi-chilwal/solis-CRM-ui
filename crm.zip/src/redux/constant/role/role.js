export const ROLE_REQUEST = "ROLE_REQUEST";
export const ROLE_SUCCESS = "ROLE_SUCCESS";
export const ROLE_FAIL = "ROLE_FAIL";
