import React from "react";

function PreviousMonthLead(){
return (
    <>
    <h2>Last 6 MONTH PERFORMANCE MONITOR</h2>
    </>
)
}
export default PreviousMonthLead;