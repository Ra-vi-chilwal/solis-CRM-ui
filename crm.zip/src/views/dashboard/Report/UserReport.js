import React from 'react';
function UserReport(){
    return (
        <>
        <div className='pt-3'>

        <p>User Logs</p>
        </div>
        </>
    )
}
export default UserReport;