import React from 'react'

const UnassignedLead = () => {
  return (
    <div>UnassignedLead</div>
  )
}

export default UnassignedLead