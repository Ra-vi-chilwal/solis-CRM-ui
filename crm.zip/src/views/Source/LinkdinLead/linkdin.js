import React from "react";
import underProcess from '../../../assets/images/under-process.gif'
function LinkedinLead(){
return (
    <>
    <div className="d-flex justify-content-center align-items-center pt-5">

    <img src={underProcess} alt="under-process" className="w-50"/>
    </div>
    </>
)
}
export default LinkedinLead;