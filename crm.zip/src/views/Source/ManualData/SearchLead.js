import React from 'react'

function SearchLead() {
  return (
    <div>SearchLead</div>
  )
}

export default SearchLead