import React from 'react';

function LandingPage(){
    return (
        <>
        Hi Welcome To the landing Page
        </>
    )
}
export default LandingPage